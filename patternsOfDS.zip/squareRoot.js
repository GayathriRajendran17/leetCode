const squareRoot = (x) => Math.floor(x ** 0.5)

console.log(squareRoot(4))
console.log(squareRoot(8))